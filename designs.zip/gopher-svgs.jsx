// GoDaily — Gopher SVG components

function GopherLogo({ size = 36 }) {
  return (
    <svg width={size} height={Math.round(size * 0.9)} viewBox="0 0 120 108" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="logo-bd" cx="42%" cy="26%" r="64%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#ceedf8"/>
          <stop offset="54%" stopColor="#8ecfe8"/>
          <stop offset="100%" stopColor="#58afc8"/>
        </radialGradient>
        <radialGradient id="logo-er" cx="50%" cy="44%" r="58%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#dca86c"/>
          <stop offset="100%" stopColor="#b07838"/>
        </radialGradient>
        <radialGradient id="logo-pu" cx="36%" cy="30%" r="62%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#1c1c2a"/>
          <stop offset="100%" stopColor="#040412"/>
        </radialGradient>
        <radialGradient id="logo-sn" cx="44%" cy="34%" r="58%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#ecc898"/>
          <stop offset="100%" stopColor="#c28060"/>
        </radialGradient>
      </defs>
      {/* Ears */}
      <ellipse cx="30" cy="27" rx="14" ry="13" fill="url(#logo-bd)"/>
      <ellipse cx="30" cy="29.5" rx="8" ry="7" fill="url(#logo-er)"/>
      <ellipse cx="90" cy="27" rx="14" ry="13" fill="url(#logo-bd)"/>
      <ellipse cx="90" cy="29.5" rx="8" ry="7" fill="url(#logo-er)"/>
      {/* Head */}
      <ellipse cx="60" cy="62" rx="48" ry="44" fill="url(#logo-bd)"/>
      {/* Eye whites */}
      <circle cx="40" cy="54" r="18" fill="white"/>
      <circle cx="80" cy="54" r="18" fill="white"/>
      <circle cx="40" cy="55" r="17.5" fill="none" stroke="#cde6f2" strokeWidth="0.8"/>
      <circle cx="80" cy="55" r="17.5" fill="none" stroke="#cde6f2" strokeWidth="0.8"/>
      {/* Pupils */}
      <circle cx="41.5" cy="55.5" r="11.5" fill="url(#logo-pu)"/>
      <circle cx="81.5" cy="55.5" r="11.5" fill="url(#logo-pu)"/>
      {/* Primary highlights */}
      <circle cx="44.5" cy="49.5" r="4.4" fill="white"/>
      <circle cx="84.5" cy="49.5" r="4.4" fill="white"/>
      {/* Secondary highlights */}
      <circle cx="36.5" cy="60" r="1.9" fill="white" opacity="0.5"/>
      <circle cx="76.5" cy="60" r="1.9" fill="white" opacity="0.5"/>
      {/* Snout */}
      <ellipse cx="60" cy="76" rx="25" ry="18" fill="url(#logo-sn)"/>
      {/* Nose */}
      <ellipse cx="60" cy="68.5" rx="6" ry="4.2" fill="#150904"/>
      <ellipse cx="57" cy="67" rx="1.8" ry="1.2" fill="#3a1808" opacity="0.55"/>
      {/* Teeth */}
      <rect x="52.5" y="84" width="6" height="9" rx="1.8" fill="white"/>
      <rect x="60" y="84" width="6" height="9" rx="1.8" fill="white"/>
      <rect x="58.2" y="84" width="1.8" height="9" fill="#e4e4e4" opacity="0.65"/>
    </svg>
  );
}

function GopherHero({ width = 280 }) {
  const h = Math.round(width * (392 / 280));
  return (
    <svg width={width} height={h} viewBox="0 0 280 392" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="hero-bd" cx="40%" cy="26%" r="65%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#d6f1fb"/>
          <stop offset="50%" stopColor="#90d0e8"/>
          <stop offset="100%" stopColor="#54acc8"/>
        </radialGradient>
        <radialGradient id="hero-bl" cx="50%" cy="30%" r="55%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#ecf8fd"/>
          <stop offset="100%" stopColor="#bcdef0"/>
        </radialGradient>
        <radialGradient id="hero-pu" cx="36%" cy="30%" r="62%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#1a1a2a"/>
          <stop offset="100%" stopColor="#040412"/>
        </radialGradient>
        <radialGradient id="hero-sn" cx="44%" cy="32%" r="58%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#eec898"/>
          <stop offset="100%" stopColor="#c28060"/>
        </radialGradient>
        <radialGradient id="hero-er" cx="50%" cy="44%" r="58%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#dca86a"/>
          <stop offset="100%" stopColor="#ae7636"/>
        </radialGradient>
        <radialGradient id="hero-ft" cx="50%" cy="28%" r="60%" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="#72bcd8"/>
          <stop offset="100%" stopColor="#4896b2"/>
        </radialGradient>
        <filter id="hero-sh" x="-20%" y="-15%" width="140%" height="140%">
          <feDropShadow dx="0" dy="5" stdDeviation="7" floodColor="#0d2236" floodOpacity="0.09"/>
        </filter>
        <filter id="hero-hsh" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="3" stdDeviation="5" floodColor="#0d2236" floodOpacity="0.08"/>
        </filter>
      </defs>

      {/* Ground shadow */}
      <ellipse cx="140" cy="384" rx="80" ry="8" fill="#7ec8e0" opacity="0.2"/>

      {/* Body */}
      <ellipse cx="140" cy="272" rx="76" ry="84" fill="url(#hero-bd)" filter="url(#hero-sh)"/>
      {/* Belly */}
      <ellipse cx="140" cy="278" rx="46" ry="60" fill="url(#hero-bl)"/>

      {/* Left arm — relaxed at side */}
      <ellipse cx="57" cy="258" rx="24" ry="15" fill="url(#hero-bd)" transform="rotate(-30 57 258)"/>
      <ellipse cx="43" cy="270" rx="16" ry="13" fill="url(#hero-bd)"/>

      {/* Right arm — raised, pointing/waving */}
      <ellipse cx="222" cy="240" rx="32" ry="15" fill="url(#hero-bd)" transform="rotate(24 222 240)"/>
      <circle cx="243" cy="228" r="14" fill="url(#hero-bd)"/>
      {/* Pointing finger */}
      <ellipse cx="251" cy="215" rx="7" ry="11.5" fill="url(#hero-bd)" transform="rotate(-16 251 215)"/>
      <ellipse cx="259" cy="221" rx="6.5" ry="10" fill="url(#hero-bd)" transform="rotate(6 259 221)"/>

      {/* Legs */}
      <ellipse cx="110" cy="342" rx="22" ry="18" fill="url(#hero-bd)"/>
      <ellipse cx="170" cy="342" rx="22" ry="18" fill="url(#hero-bd)"/>
      {/* Feet */}
      <ellipse cx="103" cy="358" rx="30" ry="13" fill="url(#hero-ft)"/>
      <ellipse cx="177" cy="358" rx="30" ry="13" fill="url(#hero-ft)"/>

      {/* Ears (drawn before head so head overlaps lower part) */}
      <ellipse cx="80" cy="77" rx="30" ry="28" fill="url(#hero-bd)"/>
      <ellipse cx="80" cy="80" rx="18" ry="16" fill="url(#hero-er)"/>
      <ellipse cx="200" cy="77" rx="30" ry="28" fill="url(#hero-bd)"/>
      <ellipse cx="200" cy="80" rx="18" ry="16" fill="url(#hero-er)"/>

      {/* Head */}
      <ellipse cx="140" cy="152" rx="98" ry="92" fill="url(#hero-bd)" filter="url(#hero-hsh)"/>

      {/* Eye whites */}
      <circle cx="102" cy="139" r="36" fill="white"/>
      <circle cx="178" cy="139" r="36" fill="white"/>
      <circle cx="102" cy="140" r="35.4" fill="none" stroke="#cce4f2" strokeWidth="1"/>
      <circle cx="178" cy="140" r="35.4" fill="none" stroke="#cce4f2" strokeWidth="1"/>

      {/* Pupils */}
      <circle cx="105" cy="141" r="23" fill="url(#hero-pu)"/>
      <circle cx="181" cy="141" r="23" fill="url(#hero-pu)"/>

      {/* Primary eye highlights */}
      <circle cx="112" cy="130" r="8.5" fill="white"/>
      <circle cx="188" cy="130" r="8.5" fill="white"/>
      {/* Secondary highlights */}
      <circle cx="96.5" cy="149" r="3.8" fill="white" opacity="0.48"/>
      <circle cx="172.5" cy="149" r="3.8" fill="white" opacity="0.48"/>

      {/* Snout */}
      <ellipse cx="140" cy="177" rx="50" ry="34" fill="url(#hero-sn)"/>
      {/* Subtle nose-bridge blend */}
      <ellipse cx="140" cy="158" rx="26" ry="13" fill="#d4a878" opacity="0.16"/>

      {/* Nose */}
      <ellipse cx="140" cy="162" rx="12" ry="8" fill="#150904"/>
      <ellipse cx="135.5" cy="159.5" rx="3.2" ry="2.1" fill="#3a1808" opacity="0.55"/>

      {/* Mouth line */}
      <path d="M106 181 Q124 190 140 191 Q156 190 174 181" stroke="#b07838" strokeWidth="1.5" fill="none" opacity="0.4"/>

      {/* Teeth */}
      <rect x="128" y="186" width="11.5" height="15.5" rx="2.5" fill="white"/>
      <rect x="141" y="186" width="11.5" height="15.5" rx="2.5" fill="white"/>
      <rect x="139.2" y="186" width="2.2" height="15.5" fill="#e6e6e6" opacity="0.65"/>
    </svg>
  );
}

Object.assign(window, { GopherLogo, GopherHero });
