// GoDaily — News Browser data

const SECTIONS = [
  { id: 'all',       label: 'All',           count: 2384 },
  { id: 'articles',  label: 'Articles',      count: 612 },
  { id: 'discussion',label: 'Discussion',    count: 891 },
  { id: 'show',      label: 'Show & Tell',   count: 124 },
  { id: 'releases',  label: 'Releases',      count: 78 },
  { id: 'trending',  label: 'Trending',      count: 156 },
  { id: 'videos',    label: 'Videos',        count: 203 },
  { id: 'podcasts',  label: 'Podcasts',      count: 64 },
  { id: 'security',  label: 'Security',      count: 47 },
  { id: 'jobs',      label: 'Jobs',          count: 88 },
  { id: 'events',    label: 'Events',        count: 31 },
  { id: 'books',     label: 'Books',         count: 12 },
];

const SOURCES = [
  { id:'hn',         name:'Hacker News',      color:'#ff6600', short:'HN',  count: 412 },
  { id:'reddit',     name:'r/golang',         color:'#ff4500', short:'r/',  count: 386 },
  { id:'lobsters',   name:'Lobsters',         color:'#ac1517', short:'L',   count: 87 },
  { id:'devto',      name:'DEV.to',           color:'#0a0a0a', short:'DEV', count: 142 },
  { id:'github',     name:'GitHub',           color:'#24292e', short:'GH',  count: 218 },
  { id:'ghtrend',    name:'GitHub Trending',  color:'#6f42c1', short:'GT',  count: 156 },
  { id:'youtube',    name:'YouTube',          color:'#ff0000', short:'YT',  count: 203 },
  { id:'goblog',     name:'Go Blog',          color:'#00add8', short:'Go',  count: 34 },
  { id:'gorelease',  name:'Go Releases',      color:'#0a8aac', short:'Rel', count: 19 },
  { id:'goland',     name:'JetBrains',        color:'#0fa968', short:'JB',  count: 27 },
  { id:'medium',     name:'Medium',           color:'#1a8917', short:'M',   count: 168 },
  { id:'fallthr',    name:'Fallthrough',      color:'#9b4dca', short:'Ft',  count: 22 },
  { id:'mastodon',   name:'Mastodon',         color:'#6364ff', short:'Mt',  count: 53 },
  { id:'meetup',     name:'Meetup',           color:'#ed1c40', short:'Mu',  count: 18 },
  { id:'osv',        name:'OSV',              color:'#d9534f', short:'OSV', count: 47 },
];

const POPULAR_TAGS = [
  'go1.25','generics','net/http','goroutines','wasm','templ',
  'sqlite','grpc','postgres','testing','performance','memory',
  'cli','tui','kubernetes','docker','aws','observability',
  'tracing','llm','ai-agents','mcp','json','yaml',
  'crypto','tls','linter','release','proposal','vulnerability'
];

const TRENDING = [
  { ttl: 'go1.25 lands: structured logging gets its big upgrade',  src:'Go Blog · 2h' },
  { ttl: "Why I'm finally ditching gRPC for ConnectRPC in 2026", src:'r/golang · 4h' },
  { ttl: 'The hidden cost of sync.Map (with benchmarks)',        src:'DEV.to · 6h' },
  { ttl: 'mat/http: HTTP_PROXY precedence — what changed',       src:'OSV · 8h' },
  { ttl: 'Building a 60-line container in Go (Part 2)',          src:'DEV.to · 10h' },
];

// Build a list of ~28 items. Mix sections so filtering is interesting.
const RAW_ITEMS = [
  { score: 487, section:'discussion', src:'hn',      title:"Go 1.25 RC1 is out — what's actually new (and what got cut)", host:'go.dev',          author:'rsc',           time:'3h', inDigest:true,  comments: 218, tags:['go1.25','release'],          read:5, snippet:"Russ Cox writes up the highlights: structured logging promoted, range-over-func stabilised, a redesigned net/http multiplexer, and one notable proposal that didn't make the cut. Plus the schedule for Go 1.26." },
  { score: 312, section:'articles',   src:'medium',  title:'I rewrote a Python ML pipeline in Go and the result surprised me', host:'medium.com', author:'avapatel',      time:'5h', inDigest:true,  comments: 84,  tags:['performance','ai-agents'], read:11, snippet:"Six months of running a sentiment-analysis pipeline in Python with all the usual tricks vs. a from-scratch Go port. Memory dropped 4×, latency p99 dropped 11×, and the code got shorter. Here's exactly what changed." },
  { score: 268, section:'releases',   src:'gorelease', title:'go1.25.0 released', host:'go.dev',                  author:'go-team',        time:'1d', inDigest:true,  comments: 142, tags:['go1.25','release'],          read:3, snippet:"Go 1.25 is the 26th major release of Go. Highlights include a new structured logging default handler, expanded JSON v2 in stdlib (experimental), and continued improvements to the runtime scheduler." },
  { score: 241, section:'trending',  src:'ghtrend', title:'glanceapp/glance', host:'github.com/glanceapp/glance',    author:'svilenmarkov',   time:'6h',  comments: 0,   tags:['cli','tui'],                 read:0, snippet:"A self-hosted dashboard that puts all your feeds in one place. RSS, Reddit, Hacker News, GitHub releases, weather, calendar — written in Go, configured via YAML. Now at 22k stars." },
  { score: 213, section:'security',  src:'osv',     title:'GO-2026-0184: HTTP/2 CONTINUATION flood in net/http', host:'pkg.go.dev/vuln', author:'security-team', time:'1d', inDigest:true,  comments: 38,  tags:['vulnerability','net/http'],  read:4, snippet:"All versions of Go prior to 1.24.6 and 1.25.0 are affected. A malicious peer can cause unbounded memory consumption by sending an arbitrary number of CONTINUATION frames. Patch immediately." },
  { score: 198, section:'articles',  src:'devto',   title:'Goroutines are not threads — and the difference matters more than you think', host:'dev.to', author:'tnk', time:'8h', inDigest:true, comments: 67, tags:['goroutines','performance'], read:9, snippet:"A practical, illustrated tour of the Go scheduler: how G-M-P actually works, what a 'preemption' costs, and why your CPU-bound workload might be slower with GOMAXPROCS=runtime.NumCPU()." },
  { score: 178, section:'discussion', src:'reddit', title:"Is anyone else getting tired of every Go project needing a 'cmd/' folder?", host:'reddit.com', author:'gopher_2026', time:'4h', comments: 312, tags:['project-layout'], read:2, snippet:"I get it, the standard layout works. But for a 200-line CLI, three nested folders and four go files feel like ceremony. What does your minimal-but-real layout look like?" },
  { score: 167, section:'videos',    src:'youtube', title:"Building a SQLite-backed job queue in 47 minutes — Weekend Go #61", host:'youtube.com', author:'GolangProjects', time:'7h', comments: 24, tags:['sqlite','cli'], read:47, snippet:"Live-coding a small but production-ready job queue: persistence, retries, exponential backoff, and a dead-letter queue. No frameworks. Just stdlib and modernc.org/sqlite." },
  { score: 154, section:'podcasts',  src:'fallthr', title:'Fallthrough #74 — Bill Kennedy on writing Go that ages well', host:'fallthrough.fm', author:'fallthrough', time:'1d', comments: 14, tags:['design'], read:62, snippet:"A conversation about API design, package boundaries, and the small habits that make a Go codebase still pleasant to work on five years later." },
  { score: 142, section:'show',      src:'reddit',  title:"Show: I built a free, open-source TLS handshake visualiser in Go", host:'tls-viz.dev', author:'crypto_kat', time:'9h', inDigest:true, comments: 41, tags:['crypto','tls'], read:0, snippet:"Paste a hostname, see every byte of the handshake annotated. Built with Go + HTMX. Source on GitHub. Roasts welcome." },
  { score: 134, section:'jobs',      src:'hn',      title:"Senior Go Engineer · Distributed Systems · €110-150k · Remote EU", host:'jobs.example.com', author:'flux-systems', time:'11h', comments: 0, tags:['remote','distributed'], read:0, snippet:"Flux is hiring engineers to work on our open-source workflow engine (47k stars). Heavy Go, deep distributed systems, async first. Salary bands published, 4-day week." },
  { score: 129, section:'articles',  src:'goblog',  title:'Profile-guided optimisation: one year on', host:'go.dev/blog', author:'go-team', time:'12h', inDigest:true, comments: 22, tags:['performance','pgo'], read:7, snippet:"PGO shipped stable in 1.21. We look back at adoption, the surprises (cold-path improvements were bigger than expected), and what's coming for AutoPGO in 1.26." },
  { score: 118, section:'discussion', src:'lobsters', title:"Why does Go's standard library still not have a decent CSV writer?", host:'lobste.rs', author:'thatcsvguy', time:'14h', comments: 88, tags:['stdlib','csv'], read:3, snippet:"encoding/csv works but the ergonomics are stuck in 2012. Tagged struct marshalling, streaming, quoted-field detection — every team writes their own wrapper. Time for a proposal?" },
  { score: 108, section:'videos',    src:'youtube', title:'Mythical — Grappling with the skill tree (Go MMO devlog)', host:'youtube.com', author:'lane_wagner', time:'15h', comments: 9, tags:['gamedev'], read:34, snippet:"This week on the MMO devlog: an hour of fighting with the skill-tree data model, why I'm rewriting it in Go, and what the player-facing flow looks like." },
  { score: 96, section:'show',       src:'github',  title:'caddyserver/caddy: v2.10 — automatic HTTPS for QUIC, lazy-loaded modules', host:'github.com/caddyserver/caddy', author:'mholt', time:'18h', inDigest:true, comments: 31, tags:['caddy','http3'], read:0, snippet:"A long-running PR finally lands. QUIC certificates are now issued and renewed automatically, the same way TLS ones have been for years. Plus the module loader is now lazy." },
  { score: 91, section:'articles',   src:'medium',  title:'Stop using context.TODO() — a checklist for cleaning up legacy Go services', host:'medium.com', author:'devops_pat', time:'19h', comments: 17, tags:['context','refactoring'], read:6, snippet:"Six concrete patterns we used to migrate a 4-year-old Go monorepo to fully-propagated request contexts, plus a vet-style linter we open-sourced as part of the work." },
  { score: 84, section:'trending',  src:'ghtrend',  title:'temoto/temoto', host:'github.com/temoto/temoto', author:'temoto', time:'1d', comments: 0, tags:['orchestration'], read:0, snippet:"Almost Cron, but for arbitrary distributed jobs across heterogeneous nodes. Pure Go, no external dependencies. Built by the maintainer of the robotstxt library." },
  { score: 79, section:'jobs',       src:'hn',      title:'Backend Engineer (Go + Postgres) — Health-tech, Berlin or remote', host:'jobs.example.com', author:'medicore-eu', time:'1d', comments: 0, tags:['remote','postgres'], read:0, snippet:"Series-B, profitable, 18 engineers, German-language patient platform. Looking for someone who likes Postgres as much as Go." },
  { score: 73, section:'events',     src:'meetup',  title:'GopherCon EU 2026 — call for papers closes Friday', host:'gophercon.eu', author:'gophercon-eu', time:'1d', inDigest:true, comments: 5, tags:['conference','cfp'], read:1, snippet:"Berlin, June 24-27. Talk slots, workshops, and lightning talks. Diversity-and-inclusion scholarships available. Submit before 23:59 UTC Friday." },
  { score: 68, section:'articles',   src:'devto',   title:"You don't need an ORM in Go (but you do need this 80-line helper)", host:'dev.to', author:'mihasha', time:'1d', comments: 44, tags:['sql','postgres'], read:8, snippet:"The pattern I've used in production for three years: a tiny generic helper around database/sql that gives you most of the ergonomics of an ORM, with none of the magic." },
  { score: 62, section:'podcasts',   src:'goland',  title:'GoLand Talks #18 — Roberto Clapis on building Go fuzzing into a CI loop', host:'jetbrains.com', author:'jb-podcast', time:'1d', comments: 3, tags:['fuzzing','testing'], read:48, snippet:"How Google integrates Go's native fuzzer into per-PR CI without blowing the budget, and what tooling is still missing in 2026." },
  { score: 57, section:'security',   src:'osv',     title:'GO-2026-0182: Path traversal in github.com/labstack/echo before v4.12.5', host:'pkg.go.dev/vuln', author:'security-team', time:'1d', comments: 12, tags:['vulnerability','echo'], read:3, snippet:"Static file middleware can be coaxed into serving files outside the configured root via crafted URL-encoded sequences. Upgrade to v4.12.5 or later." },
  { score: 54, section:'discussion', src:'reddit',  title:"What's your favourite 'small but life-changing' Go tool?", host:'reddit.com', author:'newbie_2026', time:'1d', comments: 156, tags:['tooling'], read:2, snippet:"Not the giant frameworks. The little 200-line CLIs you found one day and now can't imagine working without. I'll start: jq alternative gron, and the modd file-watcher." },
  { score: 49, section:'books',      src:'medium',  title:'Book review: "Go for Distributed Systems" (Manning, 2026)', host:'medium.com', author:'reviewbot', time:'2d', inDigest:true, comments: 8, tags:['book','distributed'], read:9, snippet:"A surprisingly hands-on book that takes you from a single-node service to a sharded, replicated cluster — built up incrementally over 11 chapters of real code." },
  { score: 43, section:'releases',   src:'github',  title:'spf13/cobra v2.0 — finally', host:'github.com/spf13/cobra', author:'spf13', time:'2d', comments: 27, tags:['cli','release'], read:0, snippet:"After years of deprecations, Cobra's v2 line is out. Breaking changes are listed in MIGRATION.md; almost all are mechanical and the upgrade tool handles 90% of them." },
  { score: 38, section:'videos',     src:'youtube', title:'How to implement concurrency with goroutines, channels and waitgroups', host:'youtube.com', author:'anthony-gg', time:'2d', comments: 19, tags:['goroutines'], read:24, snippet:"A clear, paced explanation aimed at engineers who've written some Go but don't yet have an intuition for when to reach for a channel vs. a mutex vs. an errgroup." },
  { score: 32, section:'show',       src:'github',  title:"Show: I'm building a Postgres-only Pub/Sub broker in Go (looking for testers)", host:'github.com/example/pgpub', author:'a-dev', time:'2d', comments: 11, tags:['postgres','pubsub'], read:0, snippet:"Why? Because the operational burden of running Kafka for ≤10k msg/s is silly, and LISTEN/NOTIFY is more than capable. Looking for people willing to break it in production." },
  { score: 28, section:'articles',   src:'lobsters', title:"Patterns for writing Go code that's easy to delete", host:'lobste.rs', author:'olderwiser', time:'3d', comments: 22, tags:['design','refactoring'], read:7, snippet:"Easy-to-delete is more useful than 'reusable'. Five concrete patterns — and three anti-patterns — drawn from a five-year-old Go service we recently retired without drama." },
];

Object.assign(window, { SECTIONS, SOURCES, POPULAR_TAGS, TRENDING, RAW_ITEMS });
