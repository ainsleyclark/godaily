// GoDaily — News Browser app (v3, data-honest)
const { useState, useMemo, useEffect } = React;

/* ── Tiny icons (stroke) ─────────────────────────── */
const Ico = ({ d, size=16, fill='none' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const ICO = {
  search:    <Ico size={16} d={<><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>}/>,
  share:     <Ico d={<><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/></>}/>,
  ext:       <Ico size={11} d={<><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></>}/>,
  clock:     <Ico size={12} d={<><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></>}/>,
  flame:     <Ico size={14} d={<path d="M8.5 14.5C6 12 7 8.5 12 5c-1 4 2 3 3 7a4 4 0 1 1-6.5 2.5z"/>}/>,
  spark:     <Ico size={14} d={<path d="M3 17l4-4 4 4 7-9"/>}/>,
  filter:    <Ico size={14} d={<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>}/>,
  envelope:  <Ico size={11} d={<><path d="M3 6h18v12H3z"/><polyline points="3 7 12 13 21 7"/></>}/>,
  arrow:     <Ico size={10} d={<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></>}/>,
  close:     <Ico size={16} d={<><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>}/>,
};

/* ── Nav (matches landing) ───────────────────────── */
function Nav() {
  const links = [['#','Features'],['#','Sources'],['/browse','Browse'],['#','Issues'],['#','GitHub']];
  return (
    <nav style={{ position:'sticky', top:0, zIndex:100, height:64, display:'flex', alignItems:'center',
      justifyContent:'space-between', padding:'0 2rem',
      background:'rgba(255,255,255,0.94)', backdropFilter:'blur(12px)',
      borderBottom:'1px solid var(--border-soft)' }}>
      <a href="#" style={{ display:'flex', alignItems:'center', gap:10, fontWeight:700, fontSize:'1.1rem', color:'var(--text)' }}>
        <GopherLogo size={32}/>GoDaily
      </a>
      <div className="nav-links" style={{ display:'flex', alignItems:'center', gap:'1.6rem' }}>
        {links.map(([h,l]) => (
          <a key={l} href={h} style={{ fontSize:'0.875rem',
            color: l === 'Browse' ? 'var(--accent-dark)' : 'var(--text-2)',
            fontWeight: l === 'Browse' ? 600 : 500 }}>{l}</a>
        ))}
        <a href="#" style={{ fontSize:'0.84rem', fontWeight:600, color:'white',
          background:'var(--accent)', padding:'8px 14px', borderRadius:8,
          boxShadow:'0 4px 12px rgba(42,168,216,0.28)' }}>Subscribe</a>
      </div>
    </nav>
  );
}

/* ── Page header ─────────────────────────────────── */
function PageHeader({ query, setQuery, totalIndexed, nextDigest }) {
  return (
    <header style={{ padding:'2.4rem 2rem 1.2rem', maxWidth:1280, margin:'0 auto' }}>
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', gap:24, flexWrap:'wrap' }}>
        <div>
          <div className="kicker">Browse the archive</div>
          <h1 className="h1" style={{ marginTop:6 }}>
            The full firehose, with{' '}
            <span style={{ color:'var(--accent)' }}>digest picks</span> marked.
          </h1>
          <p className="sub">
            Everything our pipeline collected. Use the section tabs and filters to narrow —
            and look for the <span className="inline-mark">{ICO.envelope}<span>In digest</span></span> badge to see which
            stories actually made it into the newsletter.
          </p>
        </div>
        <div className="search-wrap">
          {ICO.search}
          <input className="search" placeholder={`Search ${totalIndexed.toLocaleString()} stories…`}
            value={query} onChange={e=>setQuery(e.target.value)}/>
        </div>
      </div>
      <div className="stat-strip">
        <div className="stat">
          <div className="v">{totalIndexed.toLocaleString()}</div>
          <div className="l">Stories indexed</div>
        </div>
        <div className="stat">
          <div className="v">23</div>
          <div className="l">Live sources</div>
        </div>
        <div className="stat">
          <div className="v">312<span className="delta">issue</span></div>
          <div className="l">Latest digest</div>
        </div>
        <div className="stat">
          <div className="v">{nextDigest}<span className="delta">06:30 CET</span></div>
          <div className="l">Next digest in</div>
        </div>
      </div>
    </header>
  );
}

/* ── Tabs bar (sticky, scrolls horizontally on overflow) ──── */
function TabsBar({ section, setSection, tabStyle }) {
  return (
    <div className={`tabs-bar ${tabStyle === 'pill' ? 'style-pill' : ''}`}>
      <div className="tabs-scroll">
        {SECTIONS.map(s => (
          <button key={s.id}
            className={`tab ${s.id === section ? 'is-active' : ''}`}
            onClick={() => setSection(s.id)}>
            {s.label}
            <span className="count">{s.count.toLocaleString()}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Left filter side ────────────────────────────── */
function FilterSide({ sourceFilter, toggleSource, clearSources, range, setRange,
                       digestOnly, setDigestOnly, digestPickCount, totalCount, inDrawer=false, onClose }) {
  return (
    <aside className={inDrawer ? 'drawer-panel' : 'side'}>
      {inDrawer && (
        <div className="drawer-head">
          <h3>Filters</h3>
          <button onClick={onClose} aria-label="Close">{ICO.close}</button>
        </div>
      )}

      {/* Hero: digest-only toggle */}
      <div className="side-block digest-toggle-block">
        <button className={`digest-toggle ${digestOnly ? 'is-on' : ''}`}
          onClick={()=>setDigestOnly(!digestOnly)}>
          <span className="digest-toggle-mark">{ICO.envelope}</span>
          <span className="digest-toggle-body">
            <span className="t">Only digest picks</span>
            <span className="s">
              {digestOnly
                ? <>Showing the curated <strong>{digestPickCount}</strong>.</>
                : <>Hide the firehose. <strong>{digestPickCount}</strong> of {totalCount.toLocaleString()} made the cut.</>}
            </span>
          </span>
          <span className={`digest-toggle-knob ${digestOnly ? 'is-on' : ''}`}><span/></span>
        </button>
      </div>

      <div className="side-block">
        <h4>
          Sources
          {sourceFilter.size > 0 && <a href="#" onClick={(e)=>{ e.preventDefault(); clearSources(); }}>Clear ({sourceFilter.size})</a>}
        </h4>
        <div style={{ display:'flex', flexDirection:'column', gap:1 }}>
          {SOURCES.slice(0, 11).map(s => (
            <label key={s.id} className="src-row">
              <input type="checkbox" checked={sourceFilter.has(s.id)} onChange={()=>toggleSource(s.id)}/>
              <span className="dot" style={{ background: s.color }}/>
              <span className="nm">{s.name}</span>
              <span className="ct">{s.count}</span>
            </label>
          ))}
          <a href="#" style={{ fontSize:'0.78rem', color:'var(--accent)', padding:'6px 4px 0', fontWeight:500 }}>
            + {SOURCES.length - 11} more sources
          </a>
        </div>
      </div>

      <div className="side-block">
        <h4>Date range</h4>
        <div className="range-row">
          {['Today','Week','Month','Year','All'].map(r => (
            <button key={r} className={range === r ? 'is-on' : ''} onClick={()=>setRange(r)}>{r}</button>
          ))}
        </div>
      </div>
    </aside>
  );
}

/* ── Right aside ─────────────────────────────────── */
function RightAside({ inMobileColumn=false }) {
  return (
    <aside className={inMobileColumn ? 'aside aside-mobile-col' : 'aside'}>
      <div className="side-block">
        <h4>{ICO.flame}&nbsp;Top stories this week</h4>
        {TRENDING.map((t, i) => (
          <a key={i} href="#" className="trend-row">
            <span className="rank">{String(i+1).padStart(2,'0')}</span>
            <span className="info">
              <span className="ttl">{t.ttl}</span>
              <span className="src">{t.src}</span>
            </span>
          </a>
        ))}
        <p style={{ fontSize:'0.68rem', color:'var(--text-4)', marginTop:8, lineHeight:1.5 }}>
          Ranked by our relevance score. Click-driven trending coming soon.
        </p>
      </div>
      <div className="digest-cta">
        <h5>Skip the scroll.</h5>
        <p>Get the top picks of the day, ranked and summarised, before 6:30am.</p>
        <input type="email" placeholder="you@example.com"/>
        <button className="cta">Get the daily digest</button>
      </div>
    </aside>
  );
}

/* ── Toolbar ─────────────────────────────────────── */
function Toolbar({ sort, setSort, range, setRange, digestOnly, setDigestOnly, count, onOpenFilters }) {
  return (
    <div className="toolbar">
      <button className="chip-btn drawer-trigger" onClick={onOpenFilters}>
        {ICO.filter}&nbsp;Filters
      </button>
      <div className="seg">
        {[['hot','Hot',ICO.flame],['top','Top',ICO.spark],['new','New',ICO.clock]].map(([k,l,i]) => (
          <button key={k} className={sort === k ? 'is-on' : ''} onClick={()=>setSort(k)}>
            {i}{l}
          </button>
        ))}
      </div>
      <select className="chip-btn" value={range} onChange={e=>setRange(e.target.value)}>
        {['Today','Week','Month','Year','All'].map(r => <option key={r}>{r}</option>)}
      </select>
      <button className={`chip-btn digest-quick ${digestOnly ? 'is-on' : ''}`}
        onClick={()=>setDigestOnly(!digestOnly)}>
        {ICO.envelope}&nbsp;Only digest picks
      </button>
      <div className="meta">{count.toLocaleString()} {count === 1 ? 'story' : 'stories'}</div>
    </div>
  );
}

function AppliedFilters({ section, sourceFilter, range, digestOnly, removeSource, clearAll, setSection, setRange, setDigestOnly }) {
  const hasAny = section !== 'all' || sourceFilter.size || range !== 'Week' || digestOnly;
  if (!hasAny) return null;
  return (
    <div className="applied-row">
      <span className="lbl">Showing</span>
      {digestOnly && (
        <span className="applied-chip is-digest">
          {ICO.envelope}&nbsp;Digest picks only
          <button onClick={()=>setDigestOnly(false)}>×</button>
        </span>
      )}
      {section !== 'all' && (
        <span className="applied-chip">
          {SECTIONS.find(s=>s.id===section).label}
          <button onClick={()=>setSection('all')}>×</button>
        </span>
      )}
      {[...sourceFilter].map(sid => {
        const s = SOURCES.find(x => x.id === sid);
        return <span key={sid} className="applied-chip">{s.name}<button onClick={()=>removeSource(sid)}>×</button></span>;
      })}
      {range !== 'Week' && (
        <span className="applied-chip">Last {range.toLowerCase()}<button onClick={()=>setRange('Week')}>×</button></span>
      )}
      <a href="#" className="clear-all" onClick={(e)=>{ e.preventDefault(); clearAll(); }}>Reset all</a>
    </div>
  );
}

/* ── Single news item ────────────────────────────── */
function NewsItem({ item }) {
  const src = SOURCES.find(s => s.id === item.src);
  const section = SECTIONS.find(s => s.id === item.section);
  return (
    <article className={`item ${item.inDigest ? 'in-digest' : ''}`}>
      <div className="src-mark" style={{ background: src.color }} title={src.name}>{src.short}</div>
      <div className="item-body">
        <a href="#" className="item-title">
          {item.title}
          {item.host && <span className="ext-host">({item.host}) {ICO.ext}</span>}
        </a>
        <p className="item-snippet">{item.snippet}</p>
        <div className="item-meta">
          <span className="pill">{section?.label}</span>
          {item.inDigest && (
            <a href="#" className="digest-mark" title={`Featured in digest ${item.issue}`}>
              {ICO.envelope}<span>In digest</span>
              {item.issue && <><span className="sep"/><span className="issue">{item.issue}</span>{ICO.arrow}</>}
            </a>
          )}
          <span>via <span className="author">{src.name}</span></span>
          {item.author && <><span className="dot-sep"/><span>by {item.author}</span></>}
          <span className="dot-sep"/>
          <span>{item.time} ago</span>
        </div>
      </div>
      <div className="item-actions">
        <a href="#" title="Open" className="action-link">{ICO.ext}</a>
        <button title="Share">{ICO.share}</button>
      </div>
    </article>
  );
}

/* ── Item skeleton (loading state) ───────────────── */
function ItemSkeleton() {
  return (
    <article className="item is-skeleton">
      <div className="sk sk-mark"/>
      <div className="item-body">
        <div className="sk sk-line w70"/>
        <div className="sk sk-line w50" style={{ marginTop:8 }}/>
        <div className="sk sk-line w90" style={{ marginTop:12, height:6 }}/>
        <div className="sk sk-line w80" style={{ marginTop:6, height:6 }}/>
        <div style={{ display:'flex', gap:6, marginTop:10 }}>
          <div className="sk sk-chip"/>
          <div className="sk sk-chip" style={{ width:90 }}/>
        </div>
      </div>
    </article>
  );
}

function EmptyState({ digestOnly, clearAll }) {
  return (
    <div className="empty-state">
      <div className="empty-glyph">{ICO.envelope}</div>
      <h3>No stories match those filters</h3>
      <p>
        {digestOnly
          ? "Nothing in this slice made the digest. Try widening the date range, or include the full firehose."
          : "Try widening the date range, fewer sources, or jump back to All."}
      </p>
      <button className="cta-ghost" onClick={clearAll}>Reset all filters</button>
    </div>
  );
}

/* ── Pager ───────────────────────────────────────── */
function Pager({ totalPages = 48 }) {
  const [cur, setCur] = useState(1);
  const pages = [1,2,3,4,5];
  return (
    <nav className="pager">
      <button>‹ Prev</button>
      {pages.map(p => (
        <button key={p} className={p === cur ? 'is-on' : ''} onClick={()=>setCur(p)}>{p}</button>
      ))}
      <span className="dots">…</span>
      <button>{totalPages}</button>
      <button>Next ›</button>
    </nav>
  );
}

/* ── App ─────────────────────────────────────────── */
function App() {
  const [section, setSection] = useState('all');
  const [sort, setSort] = useState('hot');
  const [range, setRange] = useState('Week');
  const [query, setQuery] = useState('');
  const [sourceFilter, setSourceFilter] = useState(new Set());
  const [digestOnly, setDigestOnly] = useState(false);
  const [tabStyle, setTabStyle] = useState('underline');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // expose setters for tweaks
  useEffect(() => { window.__browseSetters = { setTabStyle }; }, []);

  // simulate brief filter loading whenever the filters change
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 280);
    return () => clearTimeout(t);
  }, [section, sort, range, sourceFilter, digestOnly, query]);

  const toggleSource = (val) => {
    const next = new Set(sourceFilter);
    next.has(val) ? next.delete(val) : next.add(val);
    setSourceFilter(next);
  };
  const removeSource = (v) => { const n = new Set(sourceFilter); n.delete(v); setSourceFilter(n); };

  const items = useMemo(() => {
    let out = RAW_ITEMS.filter(it => section === 'all' || it.section === section);
    if (sourceFilter.size) out = out.filter(it => sourceFilter.has(it.src));
    if (digestOnly)        out = out.filter(it => it.inDigest);
    if (query) {
      const q = query.toLowerCase();
      out = out.filter(it =>
        it.title.toLowerCase().includes(q)   ||
        it.snippet.toLowerCase().includes(q) ||
        it.author?.toLowerCase().includes(q));
    }
    if (sort === 'new')   out = [...out].sort((a,b) => parseInt(a.time) - parseInt(b.time));
    if (sort === 'top')   out = [...out].sort((a,b) => Number(b.inDigest) - Number(a.inDigest));
    // 'hot' = default order (recency-weighted relevance from the backend)
    return out;
  }, [section, sort, sourceFilter, digestOnly, query]);

  const digestPickCount = useMemo(
    () => RAW_ITEMS.filter(it => (section === 'all' || it.section === section) && it.inDigest).length,
    [section]
  );
  const totalCount = useMemo(
    () => RAW_ITEMS.filter(it => section === 'all' || it.section === section).length,
    [section]
  );

  const clearAll = () => {
    setSection('all'); setRange('Week'); setSourceFilter(new Set());
    setDigestOnly(false); setQuery('');
  };

  return (
    <>
      <Nav/>
      <PageHeader query={query} setQuery={setQuery} totalIndexed={2384} nextDigest="06:12"/>
      <TabsBar section={section} setSection={setSection} tabStyle={tabStyle}/>

      <div className="browse-layout">
        <FilterSide
          sourceFilter={sourceFilter} toggleSource={toggleSource}
          clearSources={()=>setSourceFilter(new Set())}
          range={range} setRange={setRange}
          digestOnly={digestOnly} setDigestOnly={setDigestOnly}
          digestPickCount={digestPickCount} totalCount={totalCount}/>

        <main>
          <Toolbar sort={sort} setSort={setSort} range={range} setRange={setRange}
            digestOnly={digestOnly} setDigestOnly={setDigestOnly}
            count={items.length} onOpenFilters={()=>setDrawerOpen(true)}/>
          <AppliedFilters
            section={section} sourceFilter={sourceFilter} range={range} digestOnly={digestOnly}
            removeSource={removeSource} clearAll={clearAll}
            setSection={setSection} setRange={setRange} setDigestOnly={setDigestOnly}/>

          {loading ? (
            <div className="item-list">
              {[0,1,2,3,4,5].map(i => <ItemSkeleton key={i}/>)}
            </div>
          ) : items.length === 0 ? (
            <EmptyState digestOnly={digestOnly} clearAll={clearAll}/>
          ) : (
            <>
              <div className="item-list">
                {items.map((it, i) => <NewsItem key={i} item={it}/>)}
              </div>
              <Pager/>
            </>
          )}
        </main>

        <RightAside/>
      </div>

      {/* Mobile trending — renders below feed instead of as a column */}
      <div className="mobile-aside-wrap">
        <RightAside inMobileColumn/>
      </div>

      {/* Mobile filter drawer */}
      {drawerOpen && (
        <div className="drawer-overlay" onClick={()=>setDrawerOpen(false)}>
          <div className="drawer" onClick={e=>e.stopPropagation()}>
            <FilterSide inDrawer
              sourceFilter={sourceFilter} toggleSource={toggleSource}
              clearSources={()=>setSourceFilter(new Set())}
              range={range} setRange={setRange}
              digestOnly={digestOnly} setDigestOnly={setDigestOnly}
              digestPickCount={digestPickCount} totalCount={totalCount}
              onClose={()=>setDrawerOpen(false)}/>
          </div>
        </div>
      )}

      <footer style={{ padding:'2rem 2.5rem', textAlign:'center', borderTop:'1px solid var(--border-soft)' }}>
        <div style={{ display:'flex', justifyContent:'center', gap:'1.5rem', marginBottom:'0.8rem' }}>
          <a href="#" style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:'0.88rem', fontWeight:600, color:'var(--text)' }}>
            <GopherLogo size={20}/>GoDaily
          </a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>Archive</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>RSS</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>GitHub</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>Privacy</a>
        </div>
        <p style={{ fontSize:'0.76rem', color:'var(--text-3)' }}>
          Built in Go. The Go Gopher was created by Renée French, licensed under CC 4.0.
        </p>
      </footer>
    </>
  );
}

/* ── Tweaks ──────────────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentColor": "#2aa8d8",
  "tabStyle": "underline"
}/*EDITMODE-END*/;

function TweaksApp() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--accent', tweaks.accentColor);
    root.style.setProperty('--accent-dark',  shade(tweaks.accentColor, -0.28));
    root.style.setProperty('--accent-light', tint(tweaks.accentColor, 0.65));
    root.style.setProperty('--accent-tint',  tint(tweaks.accentColor, 0.86));

    const bar = document.querySelector('.tabs-bar');
    if (bar) bar.classList.toggle('style-pill', tweaks.tabStyle === 'pill');

    if (window.__browseSetters) {
      window.__browseSetters.setTabStyle(tweaks.tabStyle);
    }
  }, [tweaks]);

  return (
    <TweaksPanel>
      <TweakSection label="Brand">
        <TweakColor label="Accent colour" value={tweaks.accentColor}
          onChange={v=>setTweak('accentColor',v)}
          options={['#2aa8d8','#00ACD7','#1a7fa8','#0FA968','#7B5EA7','#e08a4a']}/>
      </TweakSection>
      <TweakSection label="Layout">
        <TweakRadio label="Tab style" value={tweaks.tabStyle}
          options={['underline','pill']}
          onChange={v=>setTweak('tabStyle',v)}/>
      </TweakSection>
    </TweaksPanel>
  );
}

function hex2rgb(h){h=h.replace('#','');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
function rgb2hex(r,g,b){const f=v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0');return '#'+f(r)+f(g)+f(b);}
function shade(h,a){const[r,g,b]=hex2rgb(h);const k=a<0?1+a:1-a;return rgb2hex(r*k,g*k,b*k);}
function tint(h,a){const[r,g,b]=hex2rgb(h);return rgb2hex(r+(255-r)*a, g+(255-g)*a, b+(255-b)*a);}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
ReactDOM.createRoot(document.getElementById('tweaks-root')).render(<TweaksApp/>);
