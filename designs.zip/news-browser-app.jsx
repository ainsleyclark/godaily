// GoDaily — News Browser app
const { useState, useMemo, useEffect } = React;

/* ── Tiny icons (stroke) ─────────────────────────── */
const Ico = ({ d, size=16, fill='none' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const ICO = {
  search:    <Ico size={16} d={<><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>}/>,
  up:        <Ico d={<polyline points="6 15 12 9 18 15"/>}/>,
  down:      <Ico d={<polyline points="6 9 12 15 18 9"/>}/>,
  save:      <Ico d={<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>}/>,
  share:     <Ico d={<><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/></>}/>,
  hide:      <Ico d={<><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></>}/>,
  more:      <Ico d={<><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></>}/>,
  rss:       <Ico d={<><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></>}/>,
  ext:       <Ico size={11} d={<><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></>}/>,
  comments:  <Ico size={12} d={<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>}/>,
  clock:     <Ico size={12} d={<><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></>}/>,
  flame:     <Ico size={14} d={<path d="M8.5 14.5C6 12 7 8.5 12 5c-1 4 2 3 3 7a4 4 0 1 1-6.5 2.5z"/>}/>,
  spark:     <Ico size={14} d={<path d="M3 17l4-4 4 4 7-9"/>}/>,
  filter:    <Ico size={14} d={<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>}/>,
};

/* ── Reuse nav from landing ──────────────────────── */
function Nav() {
  const links = [['/','Subscribe'],['#','Features'],['#','Sources'],['/browse','Browse'],['#','Issues'],['#','GitHub']];
  const isActive = (l) => l === 'Browse';
  return (
    <nav style={{ position:'sticky', top:0, zIndex:100, height:64, display:'flex', alignItems:'center',
      justifyContent:'space-between', padding:'0 2rem',
      background:'rgba(255,255,255,0.94)', backdropFilter:'blur(12px)',
      borderBottom:'1px solid var(--border-soft)' }}>
      <a href="#" style={{ display:'flex', alignItems:'center', gap:10, fontWeight:700, fontSize:'1.1rem', color:'var(--text)' }}>
        <GopherLogo size={32}/>GoDaily
      </a>
      <div className="nav-links" style={{ display:'flex', alignItems:'center', gap:'1.6rem' }}>
        {links.map(([h,l]) => (
          <a key={l} href={h} style={{ fontSize:'0.875rem',
            color: isActive(l) ? 'var(--accent-dark)' : 'var(--text-2)',
            fontWeight: isActive(l) ? 600 : 500, transition:'color 0.15s' }}>{l}</a>
        ))}
        <a href="#" style={{ fontSize:'0.84rem', fontWeight:600, color:'white',
          background:'var(--accent)', padding:'8px 14px', borderRadius:8,
          boxShadow:'0 4px 12px rgba(42,168,216,0.28)' }}>Subscribe</a>
      </div>
    </nav>
  );
}

/* ── Page header ─────────────────────────────────── */
function PageHeader({ query, setQuery }) {
  return (
    <header style={{ padding:'2.4rem 2rem 1.2rem', maxWidth:1280, margin:'0 auto' }}>
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', gap:24, flexWrap:'wrap' }}>
        <div>
          <div className="kicker">Browse</div>
          <h1 className="h1" style={{ marginTop:6 }}>
            Every Go story we've seen, <span style={{ color:'var(--accent)' }}>filterable</span>.
          </h1>
          <p className="sub">
            The same pipeline that builds the daily digest, but raw. Tabs are sections.
            Stack source, tag and time filters to narrow.
          </p>
        </div>
        <div className="search-wrap">
          {ICO.search}
          <input className="search" placeholder="Search 2,384 stories — title, source, tag, author…"
            value={query} onChange={e=>setQuery(e.target.value)}/>
          <span className="kbd">⌘K</span>
        </div>
      </div>
      <StatStrip/>
    </header>
  );
}

function StatStrip() {
  const stats = [
    { v: '2,384', l: 'Stories indexed',     d: '+47 today' },
    { v: '23',    l: 'Live sources',        d: null },
    { v: '38',    l: 'Pulled in last hour', d: null },
    { v: '6:12',  l: 'Next digest in',      d: 'AM CET' },
  ];
  return (
    <div className="stat-strip">
      {stats.map(s => (
        <div key={s.l} className="stat">
          <div className="v">{s.v}{s.d && <span className="delta">{s.d}</span>}</div>
          <div className="l">{s.l}</div>
        </div>
      ))}
    </div>
  );
}

/* ── Tabs bar ────────────────────────────────────── */
function TabsBar({ section, setSection, tabStyle }) {
  return (
    <div className={`tabs-bar ${tabStyle === 'pill' ? 'style-pill' : ''}`}>
      <div className="tabs-scroll">
        {SECTIONS.map(s => (
          <button key={s.id}
            className={`tab ${s.id === section ? 'is-active' : ''}`}
            onClick={() => setSection(s.id)}>
            {s.label}
            <span className="count">{s.count.toLocaleString()}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Filter sidebar (left) ───────────────────────── */
function FilterSide({ sourceFilter, toggleSource, clearSources, tagFilter, toggleTag, range, setRange }) {
  return (
    <aside className="side">
      <div className="side-block">
        <h4>
          Sources
          {sourceFilter.size > 0 && <a href="#" onClick={(e)=>{ e.preventDefault(); clearSources(); }}>Clear ({sourceFilter.size})</a>}
        </h4>
        <div style={{ display:'flex', flexDirection:'column', gap:1 }}>
          {SOURCES.slice(0, 11).map(s => (
            <label key={s.id} className="src-row">
              <input type="checkbox" checked={sourceFilter.has(s.id)} onChange={()=>toggleSource(s.id)}/>
              <span className="dot" style={{ background: s.color }}/>
              <span className="nm">{s.name}</span>
              <span className="ct">{s.count}</span>
            </label>
          ))}
          <a href="#" style={{ fontSize:'0.78rem', color:'var(--accent)', padding:'6px 4px 0', fontWeight:500 }}>
            + 12 more sources
          </a>
        </div>
      </div>

      <div className="side-block">
        <h4>Date range</h4>
        <div className="range-row">
          {['Today','Week','Month','Year','All'].map(r => (
            <button key={r} className={range === r ? 'is-on' : ''} onClick={()=>setRange(r)}>{r}</button>
          ))}
        </div>
      </div>

      <div className="side-block">
        <h4>Popular tags</h4>
        <div className="tag-cloud">
          {POPULAR_TAGS.slice(0, 18).map(t => (
            <button key={t} className={`tag-chip ${tagFilter.has(t) ? 'is-on' : ''}`}
              onClick={()=>toggleTag(t)}>{t}</button>
          ))}
        </div>
      </div>

      <div className="side-block">
        <h4>Status</h4>
        <label className="src-row"><input type="checkbox"/><span className="nm">Unread only</span></label>
        <label className="src-row"><input type="checkbox"/><span className="nm">Saved</span></label>
        <label className="src-row"><input type="checkbox"/><span className="nm">In a digest</span></label>
        <label className="src-row"><input type="checkbox"/><span className="nm">Hide upvoted</span></label>
      </div>
    </aside>
  );
}

/* ── Right "Trending now" + Subscribe ────────────── */
function RightAside() {
  return (
    <aside className="aside">
      <div className="side-block">
        <h4>{ICO.flame}&nbsp;Trending right now</h4>
        {TRENDING.map((t, i) => (
          <a key={i} href="#" className="trend-row">
            <span className="rank">{String(i+1).padStart(2,'0')}</span>
            <span className="info">
              <span className="ttl">{t.ttl}</span>
              <span className="src">{t.src}</span>
            </span>
          </a>
        ))}
      </div>
      <div className="digest-cta">
        <h5>Skip the scroll.</h5>
        <p>Get the top 8 of the day, ranked and summarised, before 6:30am.</p>
        <input type="email" placeholder="you@example.com"/>
        <button className="cta">Get the daily digest</button>
      </div>
    </aside>
  );
}

/* ── Toolbar (sort, density, applied filters) ────── */
function Toolbar({ sort, setSort, range, setRange, density, setDensity, count }) {
  return (
    <>
      <div className="toolbar">
        <div className="seg">
          {[['hot','Hot',ICO.flame],['top','Top',ICO.spark],['new','New',ICO.clock],['discussed','Discussed',ICO.comments]].map(([k,l,i]) => (
            <button key={k} className={sort === k ? 'is-on' : ''} onClick={()=>setSort(k)}>
              {i}{l}
            </button>
          ))}
        </div>
        <select className="chip-btn" value={range} onChange={e=>setRange(e.target.value)}>
          {['Today','Week','Month','Year','All'].map(r => <option key={r}>{r}</option>)}
        </select>
        <button className="chip-btn">{ICO.filter}&nbsp;More filters</button>
        <a href="#" className="chip-btn">{ICO.rss}&nbsp;RSS</a>
        <div className="meta">{count.toLocaleString()} stories</div>
        <div className="seg">
          {[['compact','≡'],['comfortable','☰'],['card','▦']].map(([k,l]) => (
            <button key={k} className={density === k ? 'is-on' : ''}
              onClick={()=>setDensity(k)} title={k}
              style={{ fontSize:'0.95rem', padding:'6px 9px' }}>{l}</button>
          ))}
        </div>
      </div>
    </>
  );
}

function AppliedFilters({ section, sourceFilter, tagFilter, range, removeSource, removeTag, clearAll, setSection, setRange }) {
  const hasAny = section !== 'all' || sourceFilter.size || tagFilter.size || range !== 'Week';
  if (!hasAny) return <div className="applied-row"/>;
  return (
    <div className="applied-row">
      <span className="lbl">Showing</span>
      {section !== 'all' && (
        <span className="applied-chip">
          Section: {SECTIONS.find(s=>s.id===section).label}
          <button onClick={()=>setSection('all')}>×</button>
        </span>
      )}
      {[...sourceFilter].map(sid => {
        const s = SOURCES.find(x => x.id === sid);
        return <span key={sid} className="applied-chip">{s.name}<button onClick={()=>removeSource(sid)}>×</button></span>;
      })}
      {[...tagFilter].map(t => (
        <span key={t} className="applied-chip">#{t}<button onClick={()=>removeTag(t)}>×</button></span>
      ))}
      {range !== 'Week' && (
        <span className="applied-chip">Last {range.toLowerCase()}<button onClick={()=>setRange('Week')}>×</button></span>
      )}
      <a href="#" className="clear-all" onClick={(e)=>{ e.preventDefault(); clearAll(); }}>Reset all</a>
    </div>
  );
}

/* ── Single item ─────────────────────────────────── */
function NewsItem({ item }) {
  const [vote, setVote] = useState(0); // -1, 0, 1
  const [saved, setSaved] = useState(false);
  const src = SOURCES.find(s => s.id === item.src);
  const score = item.score + vote;
  const hot = item.score > 200;
  return (
    <article className="item">
      <div className="vote">
        <button className={`up ${vote === 1 ? 'is-on' : ''}`} onClick={()=>setVote(vote===1?0:1)} aria-label="upvote">{ICO.up}</button>
        <span className={`score ${hot ? 'hot' : ''}`}>{score}</span>
        <button className={`down ${vote === -1 ? 'is-on' : ''}`} onClick={()=>setVote(vote===-1?0:-1)} aria-label="downvote">{ICO.down}</button>
      </div>
      <div className="src-mark" style={{ background: src.color }} title={src.name}>{src.short}</div>
      <div className="item-body">
        <a href="#" className="item-title">
          {item.title}
          {item.host && <span className="ext-host">({item.host}) {ICO.ext}</span>}
        </a>
        <p className="item-snippet">{item.snippet}</p>
        <div className="item-meta">
          <span className="pill">{SECTIONS.find(s => s.id === item.section)?.label}</span>
          <span>via <span className="author">{src.name}</span></span>
          {item.author && <><span className="dot-sep"/><span>by {item.author}</span></>}
          <span className="dot-sep"/>
          <span>{item.time} ago</span>
          {item.comments > 0 && <>
            <span className="dot-sep"/>
            <span className="read">{ICO.comments} {item.comments}</span>
          </>}
          {item.read > 0 && <>
            <span className="dot-sep"/>
            <span className="read">{ICO.clock} {item.read} min</span>
          </>}
          {item.tags.length > 0 && (
            <span className="tags">
              {item.tags.slice(0, 3).map(t => <span key={t} className="tag-mini">#{t}</span>)}
            </span>
          )}
        </div>
      </div>
      <div className="item-actions">
        <button onClick={()=>setSaved(!saved)} className={saved ? 'is-saved' : ''} title="Save">{ICO.save}</button>
        <button title="Share">{ICO.share}</button>
        <button title="Hide">{ICO.hide}</button>
        <button title="More">{ICO.more}</button>
      </div>
    </article>
  );
}

/* ── Pager ───────────────────────────────────────── */
function Pager() {
  const pages = [1,2,3,4,5];
  const [cur, setCur] = useState(1);
  return (
    <nav className="pager">
      <button>‹ Prev</button>
      {pages.map(p => (
        <button key={p} className={p === cur ? 'is-on' : ''} onClick={()=>setCur(p)}>{p}</button>
      ))}
      <span className="dots">…</span>
      <button>48</button>
      <button>Next ›</button>
    </nav>
  );
}

/* ── App ─────────────────────────────────────────── */
function App() {
  const [section, setSection] = useState('all');
  const [sort, setSort] = useState('hot');
  const [range, setRange] = useState('Week');
  const [density, setDensity] = useState('comfortable');
  const [query, setQuery] = useState('');
  const [sourceFilter, setSourceFilter] = useState(new Set());
  const [tagFilter, setTagFilter] = useState(new Set());
  const [tabStyle, setTabStyle] = useState('underline');
  const [showLeft, setShowLeft] = useState(true);
  const [showRight, setShowRight] = useState(true);

  // expose setters for tweaks
  useEffect(() => {
    window.__browseSetters = { setDensity, setTabStyle, setShowLeft, setShowRight };
  }, []);

  const toggleSet = (set, setSet) => (val) => {
    const next = new Set(set);
    next.has(val) ? next.delete(val) : next.add(val);
    setSet(next);
  };
  const toggleSource = toggleSet(sourceFilter, setSourceFilter);
  const toggleTag    = toggleSet(tagFilter,    setTagFilter);
  const removeSource = (v) => { const n = new Set(sourceFilter); n.delete(v); setSourceFilter(n); };
  const removeTag    = (v) => { const n = new Set(tagFilter);    n.delete(v); setTagFilter(n); };

  const items = useMemo(() => {
    let out = RAW_ITEMS.filter(it => section === 'all' || it.section === section);
    if (sourceFilter.size) out = out.filter(it => sourceFilter.has(it.src));
    if (tagFilter.size)    out = out.filter(it => it.tags.some(t => tagFilter.has(t)));
    if (query) {
      const q = query.toLowerCase();
      out = out.filter(it => it.title.toLowerCase().includes(q) || it.snippet.toLowerCase().includes(q) || it.tags.some(t => t.includes(q)) || it.author?.toLowerCase().includes(q));
    }
    if (sort === 'new')        out = [...out].sort((a,b) => parseInt(a.time) - parseInt(b.time));
    if (sort === 'discussed')  out = [...out].sort((a,b) => b.comments - a.comments);
    if (sort === 'top')        out = [...out].sort((a,b) => b.score - a.score);
    return out;
  }, [section, sort, sourceFilter, tagFilter, query]);

  const clearAll = () => {
    setSection('all'); setRange('Week'); setSourceFilter(new Set()); setTagFilter(new Set()); setQuery('');
  };

  const layoutClass = !showLeft && !showRight ? 'no-side' : !showRight ? 'no-aside' : '';

  return (
    <>
      <Nav/>
      <PageHeader query={query} setQuery={setQuery}/>
      <TabsBar section={section} setSection={setSection} tabStyle={tabStyle}/>
      <div className={`browse-layout ${layoutClass}`}>
        {showLeft && (
          <FilterSide
            sourceFilter={sourceFilter} toggleSource={toggleSource}
            clearSources={()=>setSourceFilter(new Set())}
            tagFilter={tagFilter} toggleTag={toggleTag}
            range={range} setRange={setRange}/>
        )}
        <main>
          <Toolbar sort={sort} setSort={setSort} range={range} setRange={setRange}
            density={density} setDensity={setDensity} count={items.length}/>
          <AppliedFilters
            section={section} sourceFilter={sourceFilter} tagFilter={tagFilter} range={range}
            removeSource={removeSource} removeTag={removeTag}
            clearAll={clearAll} setSection={setSection} setRange={setRange}/>
          {items.length === 0 ? (
            <div style={{ padding:'3rem 1rem', textAlign:'center', color:'var(--text-3)', border:'1px dashed var(--border)', borderRadius:14, marginTop:8 }}>
              No stories match those filters. <a href="#" onClick={(e)=>{e.preventDefault(); clearAll();}}
                style={{ color:'var(--accent)', fontWeight:600 }}>Reset filters</a>.
            </div>
          ) : (
            <>
              <div className={`item-list density-${density}`}>
                {items.map((it, i) => <NewsItem key={i} item={it}/>)}
              </div>
              <Pager/>
            </>
          )}
        </main>
        {showRight && <RightAside/>}
      </div>
      <footer style={{ padding:'2rem 2.5rem', textAlign:'center', borderTop:'1px solid var(--border-soft)' }}>
        <div style={{ display:'flex', justifyContent:'center', gap:'1.5rem', marginBottom:'0.8rem' }}>
          <a href="#" style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:'0.88rem', fontWeight:600, color:'var(--text)' }}>
            <GopherLogo size={20}/>GoDaily
          </a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>Archive</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>RSS</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>GitHub</a>
          <a href="#" style={{ fontSize:'0.82rem', color:'var(--text-2)' }}>Privacy</a>
        </div>
        <p style={{ fontSize:'0.76rem', color:'var(--text-3)' }}>
          Built in Go. The Go Gopher was created by Renée French, licensed under CC 4.0.
        </p>
      </footer>
    </>
  );
}

/* ── Tweaks ──────────────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentColor": "#2aa8d8",
  "tabStyle": "underline",
  "density": "comfortable",
  "showLeftSidebar": true,
  "showRightSidebar": true
}/*EDITMODE-END*/;

function TweaksApp() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  useEffect(() => {
    document.documentElement.style.setProperty('--accent', tweaks.accentColor);
    // re-derive darker / lighter helper colours from the accent so the page stays harmonious
    const root = document.documentElement;
    root.style.setProperty('--accent-dark', shade(tweaks.accentColor, -0.28));
    root.style.setProperty('--accent-light', tint(tweaks.accentColor, 0.65));
    root.style.setProperty('--accent-tint',  tint(tweaks.accentColor, 0.86));

    const bar = document.querySelector('.tabs-bar');
    if (bar) bar.classList.toggle('style-pill', tweaks.tabStyle === 'pill');

    const list = document.querySelector('.item-list');
    if (list) list.className = `item-list density-${tweaks.density}`;

    // toggle sidebars through React setters
    if (window.__browseSetters) {
      window.__browseSetters.setDensity(tweaks.density);
      window.__browseSetters.setTabStyle(tweaks.tabStyle);
      window.__browseSetters.setShowLeft(tweaks.showLeftSidebar);
      window.__browseSetters.setShowRight(tweaks.showRightSidebar);
    }
  }, [tweaks]);

  return (
    <TweaksPanel>
      <TweakSection label="Brand">
        <TweakColor label="Accent colour" value={tweaks.accentColor}
          onChange={v=>setTweak('accentColor',v)}
          options={['#2aa8d8','#00ACD7','#1a7fa8','#0FA968','#7B5EA7','#e08a4a']}/>
      </TweakSection>
      <TweakSection label="Layout">
        <TweakRadio label="Tab style" value={tweaks.tabStyle}
          options={['underline','pill']}
          onChange={v=>setTweak('tabStyle',v)}/>
        <TweakRadio label="Density" value={tweaks.density}
          options={['compact','comfortable','card']}
          onChange={v=>setTweak('density',v)}/>
        <TweakToggle label="Show filter sidebar" value={tweaks.showLeftSidebar}
          onChange={v=>setTweak('showLeftSidebar',v)}/>
        <TweakToggle label="Show trending sidebar" value={tweaks.showRightSidebar}
          onChange={v=>setTweak('showRightSidebar',v)}/>
      </TweakSection>
    </TweaksPanel>
  );
}

// Quick hex shade helpers
function hex2rgb(h){h=h.replace('#','');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
function rgb2hex(r,g,b){const f=v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0');return '#'+f(r)+f(g)+f(b);}
function shade(h,a){const[r,g,b]=hex2rgb(h);const k=a<0?1+a:1-a;return rgb2hex(r*k,g*k,b*k);}
function tint(h,a){const[r,g,b]=hex2rgb(h);return rgb2hex(r+(255-r)*a, g+(255-g)*a, b+(255-b)*a);}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
ReactDOM.createRoot(document.getElementById('tweaks-root')).render(<TweaksApp/>);
