// GoDaily — News Browser data (v3, aligned with canonical schema)

// Canonical sections from backend (Release, Proposal, Conference, Discussion,
// Event, Article, Tutorial, Video, Trending, Security, Jobs). "All" is virtual.
const SECTIONS = [
  { id: 'all',         label: 'All',         count: 2384 },
  { id: 'article',     label: 'Articles',    count: 612  },
  { id: 'tutorial',    label: 'Tutorials',   count: 188  },
  { id: 'discussion',  label: 'Discussion',  count: 891  },
  { id: 'release',     label: 'Releases',    count: 78   },
  { id: 'proposal',    label: 'Proposals',   count: 42   },
  { id: 'video',       label: 'Videos',      count: 267  },
  { id: 'trending',    label: 'Trending',    count: 156  },
  { id: 'security',    label: 'Security',    count: 47   },
  { id: 'conference',  label: 'Conferences', count: 19   },
  { id: 'event',       label: 'Events',      count: 31   },
  { id: 'jobs',        label: 'Jobs',        count: 88   },
];

const SOURCES = [
  { id:'hn',         name:'Hacker News',      color:'#ff6600', short:'HN',  count: 412 },
  { id:'reddit',     name:'r/golang',         color:'#ff4500', short:'r/',  count: 386 },
  { id:'lobsters',   name:'Lobsters',         color:'#ac1517', short:'L',   count: 87  },
  { id:'devto',      name:'DEV.to',           color:'#0a0a0a', short:'DEV', count: 142 },
  { id:'github',     name:'GitHub',           color:'#24292e', short:'GH',  count: 218 },
  { id:'ghtrend',    name:'GitHub Trending',  color:'#6f42c1', short:'GT',  count: 156 },
  { id:'youtube',    name:'YouTube',          color:'#ff0000', short:'YT',  count: 267 },
  { id:'goblog',     name:'Go Blog',          color:'#00add8', short:'Go',  count: 34  },
  { id:'gorelease',  name:'Go Releases',      color:'#0a8aac', short:'Rel', count: 19  },
  { id:'goland',     name:'JetBrains',        color:'#0fa968', short:'JB',  count: 27  },
  { id:'medium',     name:'Medium',           color:'#1a8917', short:'M',   count: 168 },
  { id:'fallthr',    name:'Fallthrough',      color:'#9b4dca', short:'Ft',  count: 22  },
  { id:'mastodon',   name:'Mastodon',         color:'#6364ff', short:'Mt',  count: 53  },
  { id:'meetup',     name:'Meetup',           color:'#ed1c40', short:'Mu',  count: 18  },
  { id:'osv',        name:'OSV',              color:'#d9534f', short:'OSV', count: 47  },
];

// "Trending right now" for v1 = top-by-score, not real-time engagement
const TRENDING = [
  { ttl: 'go1.25 lands: structured logging gets its big upgrade',     src: 'Go Blog · 2h ago' },
  { ttl: "Why I'm finally ditching gRPC for ConnectRPC in 2026",      src: 'r/golang · 4h ago' },
  { ttl: 'The hidden cost of sync.Map (with benchmarks)',             src: 'DEV.to · 6h ago' },
  { ttl: 'net/http: HTTP_PROXY precedence — what changed',            src: 'OSV · 8h ago' },
  { ttl: 'Building a 60-line container in Go (Part 2)',               src: 'DEV.to · 10h ago' },
];

// Per-row data shape (v1, honest):
//   section    — single canonical section (no free-form tags)
//   src        — source id
//   title, host, author, time, snippet
//   inDigest   — boolean: did this make it into a sent digest?
//   issue      — if inDigest, the issue number it was featured in (string, optional)
//
// Notably absent: comment counts, multi-tags, vote/score in the UI, read time.
const RAW_ITEMS = [
  { section:'discussion', src:'hn',        title:"Go 1.25 RC1 is out — what's actually new (and what got cut)",                    host:'go.dev',                       author:'rsc',            time:'3h',  inDigest:true,  issue:'#312', snippet:"Russ Cox writes up the highlights: structured logging promoted, range-over-func stabilised, a redesigned net/http multiplexer, and one notable proposal that didn't make the cut. Plus the schedule for Go 1.26." },
  { section:'article',    src:'medium',    title:'I rewrote a Python ML pipeline in Go and the result surprised me',                host:'medium.com',                   author:'avapatel',       time:'5h',  inDigest:true,  issue:'#312', snippet:"Six months of running a sentiment-analysis pipeline in Python with all the usual tricks vs. a from-scratch Go port. Memory dropped 4×, latency p99 dropped 11×, and the code got shorter. Here's exactly what changed." },
  { section:'release',    src:'gorelease', title:'go1.25.0 released',                                                                 host:'go.dev',                       author:'go-team',        time:'1d',  inDigest:true,  issue:'#311', snippet:"Go 1.25 is the 26th major release of Go. Highlights include a new structured logging default handler, expanded JSON v2 in stdlib (experimental), and continued improvements to the runtime scheduler." },
  { section:'trending',   src:'ghtrend',   title:'glanceapp/glance',                                                                  host:'github.com/glanceapp/glance',  author:'svilenmarkov',   time:'6h',  inDigest:false, snippet:"A self-hosted dashboard that puts all your feeds in one place. RSS, Reddit, Hacker News, GitHub releases, weather, calendar — written in Go, configured via YAML. Now at 22k stars." },
  { section:'security',   src:'osv',       title:'GO-2026-0184: HTTP/2 CONTINUATION flood in net/http',                              host:'pkg.go.dev/vuln',              author:'security-team',  time:'1d',  inDigest:true,  issue:'#311', snippet:"All versions of Go prior to 1.24.6 and 1.25.0 are affected. A malicious peer can cause unbounded memory consumption by sending an arbitrary number of CONTINUATION frames. Patch immediately." },
  { section:'tutorial',   src:'devto',     title:'Goroutines are not threads — and the difference matters more than you think',     host:'dev.to',                       author:'tnk',            time:'8h',  inDigest:true,  issue:'#312', snippet:"A practical, illustrated tour of the Go scheduler: how G-M-P actually works, what a 'preemption' costs, and why your CPU-bound workload might be slower with GOMAXPROCS=runtime.NumCPU()." },
  { section:'discussion', src:'reddit',    title:"Is anyone else getting tired of every Go project needing a 'cmd/' folder?",       host:'reddit.com',                   author:'gopher_2026',    time:'4h',  inDigest:false, snippet:"I get it, the standard layout works. But for a 200-line CLI, three nested folders and four go files feel like ceremony. What does your minimal-but-real layout look like?" },
  { section:'video',      src:'youtube',   title:"Building a SQLite-backed job queue in 47 minutes — Weekend Go #61",                host:'youtube.com',                  author:'GolangProjects', time:'7h',  inDigest:false, snippet:"Live-coding a small but production-ready job queue: persistence, retries, exponential backoff, and a dead-letter queue. No frameworks. Just stdlib and modernc.org/sqlite." },
  { section:'video',      src:'fallthr',   title:'Fallthrough #74 — Bill Kennedy on writing Go that ages well',                       host:'fallthrough.fm',               author:'fallthrough',    time:'1d',  inDigest:false, snippet:"A conversation about API design, package boundaries, and the small habits that make a Go codebase still pleasant to work on five years later." },
  { section:'trending',   src:'reddit',    title:"Show: I built a free, open-source TLS handshake visualiser in Go",                  host:'tls-viz.dev',                  author:'crypto_kat',     time:'9h',  inDigest:true,  issue:'#310', snippet:"Paste a hostname, see every byte of the handshake annotated. Built with Go + HTMX. Source on GitHub. Roasts welcome." },
  { section:'jobs',       src:'hn',        title:"Senior Go Engineer · Distributed Systems · €110-150k · Remote EU",                  host:'jobs.example.com',             author:'flux-systems',   time:'11h', inDigest:false, snippet:"Flux is hiring engineers to work on our open-source workflow engine (47k stars). Heavy Go, deep distributed systems, async first. Salary bands published, 4-day week." },
  { section:'article',    src:'goblog',    title:'Profile-guided optimisation: one year on',                                          host:'go.dev/blog',                  author:'go-team',        time:'12h', inDigest:true,  issue:'#310', snippet:"PGO shipped stable in 1.21. We look back at adoption, the surprises (cold-path improvements were bigger than expected), and what's coming for AutoPGO in 1.26." },
  { section:'discussion', src:'lobsters',  title:"Why does Go's standard library still not have a decent CSV writer?",                host:'lobste.rs',                    author:'thatcsvguy',     time:'14h', inDigest:false, snippet:"encoding/csv works but the ergonomics are stuck in 2012. Tagged struct marshalling, streaming, quoted-field detection — every team writes their own wrapper. Time for a proposal?" },
  { section:'video',      src:'youtube',   title:'Mythical — Grappling with the skill tree (Go MMO devlog)',                          host:'youtube.com',                  author:'lane_wagner',    time:'15h', inDigest:false, snippet:"This week on the MMO devlog: an hour of fighting with the skill-tree data model, why I'm rewriting it in Go, and what the player-facing flow looks like." },
  { section:'release',    src:'github',    title:'caddyserver/caddy: v2.10 — automatic HTTPS for QUIC, lazy-loaded modules',          host:'github.com/caddyserver/caddy', author:'mholt',          time:'18h', inDigest:true,  issue:'#309', snippet:"A long-running PR finally lands. QUIC certificates are now issued and renewed automatically, the same way TLS ones have been for years. Plus the module loader is now lazy." },
  { section:'tutorial',   src:'medium',    title:'Stop using context.TODO() — a checklist for cleaning up legacy Go services',       host:'medium.com',                   author:'devops_pat',     time:'19h', inDigest:false, snippet:"Six concrete patterns we used to migrate a 4-year-old Go monorepo to fully-propagated request contexts, plus a vet-style linter we open-sourced as part of the work." },
  { section:'trending',   src:'ghtrend',   title:'temoto/temoto',                                                                     host:'github.com/temoto/temoto',     author:'temoto',         time:'1d',  inDigest:false, snippet:"Almost Cron, but for arbitrary distributed jobs across heterogeneous nodes. Pure Go, no external dependencies. Built by the maintainer of the robotstxt library." },
  { section:'jobs',       src:'hn',        title:'Backend Engineer (Go + Postgres) — Health-tech, Berlin or remote',                  host:'jobs.example.com',             author:'medicore-eu',    time:'1d',  inDigest:false, snippet:"Series-B, profitable, 18 engineers, German-language patient platform. Looking for someone who likes Postgres as much as Go." },
  { section:'conference', src:'meetup',    title:'GopherCon EU 2026 — call for papers closes Friday',                                host:'gophercon.eu',                 author:'gophercon-eu',   time:'1d',  inDigest:true,  issue:'#309', snippet:"Berlin, June 24-27. Talk slots, workshops, and lightning talks. Diversity-and-inclusion scholarships available. Submit before 23:59 UTC Friday." },
  { section:'tutorial',   src:'devto',     title:"You don't need an ORM in Go (but you do need this 80-line helper)",                 host:'dev.to',                       author:'mihasha',        time:'1d',  inDigest:false, snippet:"The pattern I've used in production for three years: a tiny generic helper around database/sql that gives you most of the ergonomics of an ORM, with none of the magic." },
  { section:'video',      src:'goland',    title:'GoLand Talks #18 — Roberto Clapis on building Go fuzzing into a CI loop',           host:'jetbrains.com',                author:'jb-podcast',     time:'1d',  inDigest:false, snippet:"How Google integrates Go's native fuzzer into per-PR CI without blowing the budget, and what tooling is still missing in 2026." },
  { section:'security',   src:'osv',       title:'GO-2026-0182: Path traversal in github.com/labstack/echo before v4.12.5',           host:'pkg.go.dev/vuln',              author:'security-team',  time:'1d',  inDigest:false, snippet:"Static file middleware can be coaxed into serving files outside the configured root via crafted URL-encoded sequences. Upgrade to v4.12.5 or later." },
  { section:'discussion', src:'reddit',    title:"What's your favourite 'small but life-changing' Go tool?",                          host:'reddit.com',                   author:'newbie_2026',    time:'1d',  inDigest:false, snippet:"Not the giant frameworks. The little 200-line CLIs you found one day and now can't imagine working without. I'll start: jq alternative gron, and the modd file-watcher." },
  { section:'proposal',   src:'github',    title:'proposal: spec: range over a chan with timeout',                                    host:'github.com/golang/go/issues',  author:'rsc',            time:'2d',  inDigest:true,  issue:'#308', snippet:"A small grammar extension that would let range loops over channels gracefully exit after a deadline. The proposal includes a survey of how often this pattern shows up in existing Go code." },
  { section:'release',    src:'github',    title:'spf13/cobra v2.0 — finally',                                                        host:'github.com/spf13/cobra',       author:'spf13',          time:'2d',  inDigest:false, snippet:"After years of deprecations, Cobra's v2 line is out. Breaking changes are listed in MIGRATION.md; almost all are mechanical and the upgrade tool handles 90% of them." },
  { section:'video',      src:'youtube',   title:'How to implement concurrency with goroutines, channels and waitgroups',             host:'youtube.com',                  author:'anthony-gg',     time:'2d',  inDigest:false, snippet:"A clear, paced explanation aimed at engineers who've written some Go but don't yet have an intuition for when to reach for a channel vs. a mutex vs. an errgroup." },
  { section:'event',      src:'meetup',    title:'London Gophers — May meetup: lightning talks night',                                host:'meetup.com/london-gophers',    author:'london-gophers',  time:'2d',  inDigest:false, snippet:"Eight lightning talks, free pizza, free drinks, and the usual end-of-evening recruitment-fair-but-friendlier. Doors 18:30, talks 19:00. Free." },
  { section:'article',    src:'lobsters',  title:"Patterns for writing Go code that's easy to delete",                                host:'lobste.rs',                    author:'olderwiser',     time:'3d',  inDigest:false, snippet:"Easy-to-delete is more useful than 'reusable'. Five concrete patterns — and three anti-patterns — drawn from a five-year-old Go service we recently retired without drama." },
];

Object.assign(window, { SECTIONS, SOURCES, TRENDING, RAW_ITEMS });
